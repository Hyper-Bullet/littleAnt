# Yolov5 + Deep Sort with PyTorch and ROS


## Introduction

This repository contains a moded version of PyTorch YOLOv5 (https://github.com/ultralytics/yolov5). 

Deep sort (https://github.com/ZQPei/deep_sort_pytorch) which tracks the objects.


## Requirements

```bash
Cython
matplotlib>=3.2.2
numpy>=1.18.5
opencv-python>=4.1.2
pillow
easydict
# pycocotools>=2.0
PyYAML>=5.3
scipy>=1.4.1
tensorboard>=2.2
torch>=1.6.0
torchvision>=0.7.0
tqdm>=4.41.0
```

## Tracking

Tracking can be run on most video formats

```bash
python3 track.py --source ...
```

- Video:  `--source file.mp4`
- Webcam:  `--source 0`
- RTSP stream:  `--source rtsp://170.93.143.139/rtplive/470011e600ef003a004ee33696235daa`
- HTTP stream:  `--source http://wmccpinetop.axiscam.net/mjpg/video.mjpg`

MOT compliant results can be saved to `inference/output` by 

```bash
python3 track.py --source ... --save-txt
```

Tracking with ros and usb_cam topic :
```bash
1. roslaunch usb_cam usb_cam-test.launch
2. cd ~/catkin_ws/src/tracking
3. python track_ros.py
4. rostopic echo /is_red
```
